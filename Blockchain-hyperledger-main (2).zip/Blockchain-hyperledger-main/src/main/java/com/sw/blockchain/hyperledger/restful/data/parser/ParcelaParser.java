package com.sw.blockchain.hyperledger.restful.data.parser;

import com.sw.blockchain.hyperledger.restful.data.dto.ParcelaDTO;
import com.sw.blockchain.hyperledger.restful.models.Parcela;

public class ParcelaParser {
	public static ParcelaDTO toDto(Parcela parcela) {
        return BaseParser.parse(parcela,ParcelaDTO.class);
    }
    public static Parcela fromDto(ParcelaDTO parcelaDTO) {
        return BaseParser.parse(parcelaDTO,Parcela.class);
    } 
}
