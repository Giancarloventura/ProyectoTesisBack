package com.sw.blockchain.hyperledger.restful.util;

public class Format {
    public static final String DATE_TIME = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE = "yyyy-MM-dd";

    public static String trim(String str) {
        return str.trim().replaceAll(" +", " ");
    }
}
