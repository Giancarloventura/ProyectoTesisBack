package com.sw.blockchain.hyperledger.restful.models;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="inspector")
public class Inspector {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="idInspector")
	private Long idInspector;
	@Column(name="nombre")
	private String nombre;
	@Column(name="apellidoPaterno")
	private String apellidoPaterno;
	@Column(name="apellidoMaterno")
	private String apellidoMaterno;
	@Column(name="correo")
	private String correo;
	@Column(name="dni")
	private String dni;
	//Foreign Key
	@OneToOne
	@JoinColumn(name = "Administrador_idAdministrador", insertable = false, updatable = false)
	private Administrador administrador;
	
	@OneToMany(mappedBy = "inspector")
    private List<Agricultor> agricultores;
}
