package com.sw.blockchain.hyperledger.restful.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import javax.validation.Valid;

import com.sw.blockchain.hyperledger.restful.data.dto.RegistroDTO;
import com.sw.blockchain.hyperledger.restful.data.dto.SesionDTO;
import com.sw.blockchain.hyperledger.restful.data.dto.UsuarioDTO;
import com.sw.blockchain.hyperledger.restful.data.parser.BaseParser;
import com.sw.blockchain.hyperledger.restful.data.parser.UsuarioParser;
import com.sw.blockchain.hyperledger.restful.data.repository.IUsuarioDao;
import com.sw.blockchain.hyperledger.restful.models.Usuario;
import com.sw.blockchain.hyperledger.restful.services.IUsuarioService;
import com.sw.blockchain.hyperledger.restful.util.exceptions.BadCredentialsException;
import com.sw.blockchain.hyperledger.restful.util.exceptions.NotFoundException;
import com.sw.blockchain.hyperledger.restful.util.message.UsuarioMessages;

@Service
public class UsuarioService implements IUsuarioService{
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	private IUsuarioDao usuarioDao;
	
	@Override
	public UsuarioDTO registroUsuario(@Valid RegistroDTO registroDTO) {
		Usuario usuario = UsuarioParser.fromDto(registroDTO);
		usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));
		LocalDateTime localDateTime = LocalDateTime.now();
		Date currentTime = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
		usuario.setCreatedDate(currentTime);
		usuario.setModifyDate(currentTime);
		this.usuarioDao.save(usuario);
		UsuarioDTO usuarioDTO = UsuarioParser.toDto(usuario);
		usuarioDTO.setPassword(null);
		return usuarioDTO;
	}

	@Override
	public SesionDTO inicioSesion(SesionDTO sesionDTO) {
		Usuario usuario = this.usuarioDao.findByEmail(sesionDTO.getEmail())
				.orElseThrow(() -> new NotFoundException(UsuarioMessages.NOT_FOUND));
		if (!passwordEncoder.matches(sesionDTO.getPassword(), usuario.getPassword())) {
			throw new BadCredentialsException(UsuarioMessages.BAD_CREDENTIALS);
		}
		sesionDTO.setPassword(null);
		sesionDTO.setIdUsuario(usuario.getIdUsuario());
		return sesionDTO;
	}

	@Override
	public void editarUsuario(UsuarioDTO usuarioDTO) {
		Usuario user = this.usuarioDao
				.findByIdUsuarioAndEmail(usuarioDTO.getIdUsuario(), usuarioDTO.getEmail())
				.orElseThrow(() -> new NotFoundException(UsuarioMessages.NOT_FOUND));
		if(usuarioDTO.getPassword()!=null && !usuarioDTO.getPassword().trim().isEmpty()) {
			usuarioDTO.setPassword(passwordEncoder.encode(usuarioDTO.getPassword()));
		}
		LocalDateTime localDateTime = LocalDateTime.now();
		Date currentTime = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
		user.setModifyDate(currentTime);
		Usuario updatedUser = BaseParser.copyProperties(usuarioDTO, user);
		this.usuarioDao.save(updatedUser);
	}

}
