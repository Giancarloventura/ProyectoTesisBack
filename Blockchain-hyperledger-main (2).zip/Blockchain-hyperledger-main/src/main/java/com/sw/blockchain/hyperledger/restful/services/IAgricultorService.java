package com.sw.blockchain.hyperledger.restful.services;

import java.util.List;

import com.sw.blockchain.hyperledger.restful.data.dto.AgricultorDTO;

public interface IAgricultorService {
	public void guardar(AgricultorDTO dto);
	public List<AgricultorDTO> obtenerLista();
	public void eliminar(Long id);
}
