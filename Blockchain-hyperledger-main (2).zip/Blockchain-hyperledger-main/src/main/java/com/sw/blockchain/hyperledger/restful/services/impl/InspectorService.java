package com.sw.blockchain.hyperledger.restful.services.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sw.blockchain.hyperledger.restful.data.dto.InspectorDTO;
import com.sw.blockchain.hyperledger.restful.data.parser.InspectorParser;
import com.sw.blockchain.hyperledger.restful.data.repository.IInspectorDao;
import com.sw.blockchain.hyperledger.restful.models.Inspector;
import com.sw.blockchain.hyperledger.restful.services.IInspectorService;

@Service
public class InspectorService implements IInspectorService{
	@Autowired
	private IInspectorDao inspectoresDao;

	@Override
	public void guardar(InspectorDTO entity) {
		this.inspectoresDao.save(InspectorParser.fromDto(entity));
	}

	@Override
	public List<InspectorDTO> obtenerLista() {

		List<Inspector> inspectores = new ArrayList<>();
		inspectores.addAll(this.inspectoresDao
				.findAll());
		return inspectores.stream().map(InspectorParser::toDto).collect(Collectors.toList());
	}

	@Override
	public void eliminar(Long id) {
		this.inspectoresDao.deleteById(id);
	}

}
