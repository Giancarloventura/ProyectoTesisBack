package com.sw.blockchain.hyperledger.restful.data.dto;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class ParcelaDTO implements Serializable{
	
	private Long idParcela;
	@NotNull
	private String descripcion;
	@NotNull
	private Date fechaInicio;
	@NotNull
	private Date fechaFin;
	@NotNull
	private Integer tamanoHa;
	@NotNull
	private String tipoCafe;
	//Foreign key
	private Long agricultor_idAgricultor;
	//
	private Long registroActividades_idRegistroActividades;
	private Long registroCosecha_idRegistroCosecha;
	private Long inventarioInsumos_idInventarioInsumos;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
