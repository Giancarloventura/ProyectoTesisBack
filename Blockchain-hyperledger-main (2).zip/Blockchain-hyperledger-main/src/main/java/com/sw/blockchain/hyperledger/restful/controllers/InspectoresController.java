package com.sw.blockchain.hyperledger.restful.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sw.blockchain.hyperledger.restful.data.dto.InspectorDTO;
import com.sw.blockchain.hyperledger.restful.response.RestResponse;
import com.sw.blockchain.hyperledger.restful.services.IInspectorService;
import com.sw.blockchain.hyperledger.restful.util.message.InspectorMessages;

@RestController
@RequestMapping("/api/inpectores")
public class InspectoresController {
	@Autowired
	private IInspectorService inspectorService;
	
	@PostMapping(path = "/save", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> guardar(@Valid @RequestBody InspectorDTO agricultorDTO) {
		this.inspectorService.guardar(agricultorDTO);
		RestResponse restResponse = new RestResponse(HttpStatus.OK, InspectorMessages.SUCCESS_SAVE);
		return ResponseEntity.status(restResponse.getStatus()).body(restResponse);
	}

	@GetMapping(path = "/list", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> obtenerTodos() {
		RestResponse restResponse = new RestResponse(HttpStatus.OK, InspectorMessages.SUCCESS_GET,
				this.inspectorService.obtenerLista());
		return ResponseEntity.status(restResponse.getStatus()).body(restResponse);
	}
	
	@DeleteMapping(path = "/delete/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> eliminar(@PathVariable("id") Long id) {
		this.inspectorService.eliminar(id);
		RestResponse restResponse = new RestResponse(HttpStatus.OK, InspectorMessages.SUCCESS_DELETE);
		return ResponseEntity.status(restResponse.getStatus()).body(restResponse);
	}
}
