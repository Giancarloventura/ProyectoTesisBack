package com.sw.blockchain.hyperledger.restful.util.message;

public class InspectorMessages {
	public static final String ERROR_GET = "Error al obtener el(los) inspector";
	public static final String SUCCESS_SAVE = "Se ha registrado el inspector correctamente";
	public static final String SUCCESS_GET = "Se han obtenido los inspectores correctamente";
	public static final String SUCCESS_DELETE = "Se ha eliminado el inspector correctamente";
}
