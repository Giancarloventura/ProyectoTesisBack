package com.sw.blockchain.hyperledger.restful.util.message;

public class ParcelaMessages {
	public static final String ERROR_GET = "Error al obtener la(las) parcela";
	public static final String SUCCESS_SAVE = "Se ha registrado la parcela correctamente";
	public static final String SUCCESS_GET = "Se han obtenido las parcelas correctamente";
	public static final String SUCCESS_DELETE = "Se ha eliminado la parcela correctamente";
}
