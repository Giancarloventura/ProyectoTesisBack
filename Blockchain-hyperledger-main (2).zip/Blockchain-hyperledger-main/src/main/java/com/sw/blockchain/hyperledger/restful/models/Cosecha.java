package com.sw.blockchain.hyperledger.restful.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="cosecha")
public class Cosecha {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="idCosecha")
	private Long idCosecha;
	@Column(name="peso_kilos")
	private String pesoKilos;
	@Column(name="costo")
	private Float costo;
	//Foreign Keys
	@ManyToOne
	@JoinColumn(name="RegistroCosecha_idRegistroCosecha", insertable = false, updatable = false)
	private RegistroCosecha cosecha;
}
