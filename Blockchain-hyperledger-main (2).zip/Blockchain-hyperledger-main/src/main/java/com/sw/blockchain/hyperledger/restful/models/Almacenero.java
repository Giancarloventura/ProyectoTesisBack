package com.sw.blockchain.hyperledger.restful.models;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.OneToOne;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="almacenero")
public class Almacenero {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="idAlmacenero")
	private Long idAlmacenero;
	@Column(name="nombre")
	private String nombre;
	@Column(name="ApellidoPaterno")
	private String apellidoPaterno;
	@Column(name="ApellidoMaterno")
	private String apellidoMaterno;
	@Column(name="correo")
	private String correo;
	@Column(name="dni")
	private Long dni;
	
	//Foreign Key
	@OneToOne
	@JoinColumn(name = "administrador_idAdministrador", insertable = false, updatable = false)
	private Administrador administrador;
	
	@OneToMany(mappedBy = "almacenero")
    private List<Insumo> insumos;
}