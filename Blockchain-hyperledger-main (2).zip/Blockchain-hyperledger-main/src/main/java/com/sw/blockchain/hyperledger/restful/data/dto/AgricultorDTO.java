package com.sw.blockchain.hyperledger.restful.data.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class AgricultorDTO implements Serializable{
	
	private Long idAgricultor;
    @NotNull
	private String nombre;
    @NotNull
	private String apellidoPaterno;
    @NotNull
	private String apellidoMaterno;
    @NotNull
	private String correo;
    @NotNull
	private String dni;
	//Foreign key
	
    private static final long serialVersionUID = 1L;
}
