package com.sw.blockchain.hyperledger.restful.data.parser;

import com.sw.blockchain.hyperledger.restful.data.dto.AgricultorDTO;
import com.sw.blockchain.hyperledger.restful.models.Agricultor;

public class AgricultorParser {
	public static AgricultorDTO toDto(Agricultor agricultor) {
        return BaseParser.parse(agricultor,AgricultorDTO.class);
    }
    public static Agricultor fromDto(AgricultorDTO agricultorDTO) {
        return BaseParser.parse(agricultorDTO,Agricultor.class);
    }
}
