package com.sw.blockchain.hyperledger.restful.services;

import com.sw.blockchain.hyperledger.restful.data.dto.RegistroDTO;
import com.sw.blockchain.hyperledger.restful.data.dto.SesionDTO;
import com.sw.blockchain.hyperledger.restful.data.dto.UsuarioDTO;

public interface IUsuarioService {
	 UsuarioDTO registroUsuario(RegistroDTO registroDTO);
	 SesionDTO inicioSesion(SesionDTO sesionDTO);
	 void editarUsuario(UsuarioDTO usuarioDTO);
}
