package com.sw.blockchain.hyperledger.restful.util.message;

public class UsuarioMessages {
	public static final String ERROR_LOGIN = "Error en el inicio de sesion";
	public static final String NOT_FOUND = "Error al acceder a su usuario";
	public static final String BAD_CREDENTIALS = "Las credenciales ingresadas no son validas";
	public static final String SUCCESS_SAVE = "Se ha registrado el usuario correctamente";
	public static final String SUCCESS_LOGIN = "Inicio de sesion exitoso";
	public static final String SUCCESS_EDIT = "Se ha editado el usuario correctamente";
}
