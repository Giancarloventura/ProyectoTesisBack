package com.sw.blockchain.hyperledger.restful.models;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="registrocosecha")
public class RegistroCosecha {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="idRegistroCosecha")
	private Long idRegistroCosecha;
	@Column(name="fecha")
	private Date fecha;
	@Column(name="total_sacos")
	private Float totalSacos;
	@Column(name="total_costo")
	private Float totalCosto;
	//Foreign key
	@OneToOne
	@JoinColumn(name = "Parcela_idParcela", insertable = false, updatable = false)
	private Parcela parcela;
	
	@Column(name = "Parcela_idParcela")
	private Long parcela_idParcela;
	
	@OneToMany(mappedBy = "cosecha")
    private List<Cosecha> cosechas;
}