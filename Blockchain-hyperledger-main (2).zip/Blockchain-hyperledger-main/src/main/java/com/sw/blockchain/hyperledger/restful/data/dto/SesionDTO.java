package com.sw.blockchain.hyperledger.restful.data.dto;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SesionDTO {
	@JsonInclude(JsonInclude.Include.NON_NULL)
    private Long idUsuario;
    @NotNull
    @Pattern(regexp = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$",
            message = "Email ingresado no es valido")
    private String email;
    @NotNull
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String password;
}
