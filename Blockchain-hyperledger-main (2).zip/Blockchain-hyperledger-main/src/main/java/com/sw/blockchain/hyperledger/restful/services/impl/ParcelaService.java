package com.sw.blockchain.hyperledger.restful.services.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sw.blockchain.hyperledger.restful.data.dto.ParcelaDTO;
import com.sw.blockchain.hyperledger.restful.data.parser.ParcelaParser;
import com.sw.blockchain.hyperledger.restful.data.repository.IParcelaDao;
import com.sw.blockchain.hyperledger.restful.models.Parcela;
import com.sw.blockchain.hyperledger.restful.services.IParcelaService;

@Service
public class ParcelaService implements IParcelaService{
	@Autowired
	private IParcelaDao parcelaDao;

	@Override
	public void guardar(ParcelaDTO entity) {
		this.parcelaDao.save(ParcelaParser.fromDto(entity));
	}

	@Override
	public List<ParcelaDTO> obtenerLista() {
		List<Parcela> inspectores = new ArrayList<>();
		inspectores.addAll(this.parcelaDao
				.findAll());
		return inspectores.stream().map(ParcelaParser::toDto).collect(Collectors.toList());
	}

	@Override
	public void eliminar(Long id) {
		this.parcelaDao.deleteById(id);
	}
}
