package com.sw.blockchain.hyperledger.restful.models;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="parcela")
public class Parcela {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="idParcela")
	private Long idParcela;
	@Column(name="Descripcion")
	private String descripcion;
	@Column(name="FechaInicio")
	private Date fechaInicio;
	@Column(name="FechaFin")
	private Date fechaFin;
	@Column(name="Tamano_ha")
	private Integer tamanoHa;
	@Column(name="tipocafe")
	private String tipoCafe;
	//Foreign key
	
	@ManyToOne
	@JoinColumn(name="Agricultor_idAgricultor", insertable = false, updatable = false)
	private Agricultor agricultor;
	
	@Column(name="Agricultor_idAgricultor")
	private Long idAgricultor;
	
	@OneToMany(mappedBy = "parcela")
    private List<RegistroActividad> registroActividades;
	
	@OneToMany(mappedBy = "parcela")
    private List<Inventario> inventarios;
	
	@OneToMany(mappedBy = "parcela")
    private List<Foto> fotos;
	//@Column(name="Agricultor_Inspector_idInspector")
	//private Long agricultor_inspector_idInspector;
	//@Column(name="Agricultor_Inspector_Administrador_idAdministrador")
	//private Long agricultor_inspector_administrador_idAdministrador;
	//@Column(name="Agricultor_Inspector_Administrador_Almacenero_idAlmacenero")
	//private Long agricultor_inspector_administrador_almacenero_idAlmacenero;
	//
	@Column(name="RegistroActividades_idRegistroActividades")
	private Long registroActividades_idRegistroActividades;
	@Column(name="RegistroCosecha_idRegistroCosecha")
	private Long registroCosecha_idRegistroCosecha;
	@Column(name="InventarioInsumos_idInventarioInsumos")
	private Long inventarioInsumos_idInventarioInsumos;
}