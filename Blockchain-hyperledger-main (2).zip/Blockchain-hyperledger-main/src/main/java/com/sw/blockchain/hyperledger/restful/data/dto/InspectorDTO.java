package com.sw.blockchain.hyperledger.restful.data.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class InspectorDTO implements Serializable{
	
	private Long idInspector;
	@NotNull
	private String nombre;
	@NotNull
	private String apellidoPaterno;
	@NotNull
	private String apellidoMaterno;
	@NotNull
	private String correo;
	@NotNull
	private String dni;
	//Foreign Keys
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
