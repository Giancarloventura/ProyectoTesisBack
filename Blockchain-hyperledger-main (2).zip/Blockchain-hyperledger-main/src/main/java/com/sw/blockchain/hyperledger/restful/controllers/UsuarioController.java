package com.sw.blockchain.hyperledger.restful.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sw.blockchain.hyperledger.restful.data.dto.RegistroDTO;
import com.sw.blockchain.hyperledger.restful.data.dto.SesionDTO;
import com.sw.blockchain.hyperledger.restful.data.dto.UsuarioDTO;
import com.sw.blockchain.hyperledger.restful.response.RestResponse;
import com.sw.blockchain.hyperledger.restful.services.IUsuarioService;
import com.sw.blockchain.hyperledger.restful.util.message.UsuarioMessages;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {
	@Autowired
	private IUsuarioService usuarioService;
	
	@PostMapping(path = "/login", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> iniciarSesion(@Valid @RequestBody SesionDTO sesionDTO) {
		SesionDTO sesion = this.usuarioService.inicioSesion(sesionDTO);
		RestResponse restResponse = new RestResponse(HttpStatus.OK, UsuarioMessages.SUCCESS_LOGIN, sesion);
		return ResponseEntity.status(restResponse.getStatus()).body(restResponse);
	}
	@PostMapping(path = "/edit", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> editarUsuario(@Valid @RequestBody UsuarioDTO usuarioDTO) {
		this.usuarioService.editarUsuario(usuarioDTO);
		RestResponse restResponse = new RestResponse(HttpStatus.OK, UsuarioMessages.SUCCESS_EDIT);
		return ResponseEntity.status(restResponse.getStatus()).body(restResponse);
	}
	@PostMapping(path = "/register", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> registrarUsuario(@Valid @RequestBody RegistroDTO registroDTO) {
		UsuarioDTO registro = this.usuarioService.registroUsuario(registroDTO);
		RestResponse restResponse = new RestResponse(HttpStatus.OK, UsuarioMessages.SUCCESS_SAVE, registro);
		return ResponseEntity.status(restResponse.getStatus()).body(restResponse);
	}
}
