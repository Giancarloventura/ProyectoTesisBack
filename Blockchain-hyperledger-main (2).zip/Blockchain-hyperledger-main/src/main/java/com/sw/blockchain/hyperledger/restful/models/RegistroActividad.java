package com.sw.blockchain.hyperledger.restful.models;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="registroactividades")
public class RegistroActividad {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="idRegistroActividades")
	private Long idRegistroActividad;
	@Column(name="fecha")
	private String fecha;
	@Column(name="costoTotal")
	private Float costoTotal;
	//Foreign Key
	@ManyToOne
	@JoinColumn(name="Parcela_idParcela", insertable = false, updatable = false)
	private Parcela parcela;
	
	@Column(name = "Parcela_idParcela")
	private Long parcela_idParcela;
	
	@OneToMany(fetch = FetchType.EAGER,mappedBy = "registroActividad")
	private List<Actividad> actividades;
}