package com.sw.blockchain.hyperledger.restful.services;

import java.util.List;

import com.sw.blockchain.hyperledger.restful.data.dto.InspectorDTO;

public interface IInspectorService {
	public void guardar(InspectorDTO dto);
	public List<InspectorDTO> obtenerLista();
	public void eliminar(Long id);
}
