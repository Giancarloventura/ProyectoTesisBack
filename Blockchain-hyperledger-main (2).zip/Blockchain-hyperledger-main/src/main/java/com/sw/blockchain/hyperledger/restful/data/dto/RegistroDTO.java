package com.sw.blockchain.hyperledger.restful.data.dto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegistroDTO {
	@Pattern(regexp = "^[\\\\w-\\\\.]+@([\\\\w-]+\\\\.)+[\\\\w-]{2,4}$",
    message = "Email ingresado no es valido")
    @NotNull
    private String email;
    @NotNull
    private String password;
}
