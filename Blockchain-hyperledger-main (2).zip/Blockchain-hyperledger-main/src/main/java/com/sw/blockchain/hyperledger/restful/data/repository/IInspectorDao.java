package com.sw.blockchain.hyperledger.restful.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sw.blockchain.hyperledger.restful.models.Inspector;

public interface IInspectorDao extends JpaRepository<Inspector, Long>{

}
