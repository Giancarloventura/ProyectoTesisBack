package com.sw.blockchain.hyperledger.restful.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="administrador")
public class Administrador {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="idAdministrador")
	private Long idAdministrador;
	@Column(name="nombre")
	private String nombre;
	@Column(name="apellidoPaterno")
	private String apellidoPaterno;
	@Column(name="apellidoMaterno")
	private String apellidoMaterno;
	@Column(name="correo")
	private String correo;
	@Column(name="dni")
	private Integer dni;
}