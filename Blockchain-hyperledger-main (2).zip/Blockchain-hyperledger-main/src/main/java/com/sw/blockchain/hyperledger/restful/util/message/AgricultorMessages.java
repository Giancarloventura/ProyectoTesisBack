package com.sw.blockchain.hyperledger.restful.util.message;

public class AgricultorMessages {
	public static final String ERROR_GET = "Error al obtener el(los) agricultor";
	public static final String SUCCESS_SAVE = "Se ha registrado el agricultor correctamente";
	public static final String SUCCESS_GET = "Se han obtenido los agricultores correctamente";
	public static final String SUCCESS_DELETE = "Se ha eliminado el agricultor correctamente";
}
