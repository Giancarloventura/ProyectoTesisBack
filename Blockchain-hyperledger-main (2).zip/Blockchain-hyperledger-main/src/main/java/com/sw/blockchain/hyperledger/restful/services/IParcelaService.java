package com.sw.blockchain.hyperledger.restful.services;

import java.util.List;

import com.sw.blockchain.hyperledger.restful.data.dto.ParcelaDTO;

public interface IParcelaService {
	public void guardar(ParcelaDTO dto);
	public List<ParcelaDTO> obtenerLista();
	public void eliminar(Long id);
}
