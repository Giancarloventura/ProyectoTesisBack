package com.sw.blockchain.hyperledger.restful.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="insumo")
public class Insumo {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="idInsumo")
	private Long idInsumo;
	@Column(name="nombre")
	private String nombre;
	@Column(name="estado")
	private String estado;
	@Column(name="valor")
	private Float valor;
	@Column(name="cantidad")
	private Integer cantidad;
	//Foreign key
	@ManyToOne
	@JoinColumn(name="Almacenero_idAlmacenero", insertable = false, updatable = false)
	private Almacenero almacenero;
}