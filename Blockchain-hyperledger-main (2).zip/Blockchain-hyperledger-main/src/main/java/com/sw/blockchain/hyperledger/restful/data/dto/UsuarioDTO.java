package com.sw.blockchain.hyperledger.restful.data.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UsuarioDTO {
    @NotNull
    private Long idUsuario;
    @Email
    @NotNull
    private String email;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String password;
}
