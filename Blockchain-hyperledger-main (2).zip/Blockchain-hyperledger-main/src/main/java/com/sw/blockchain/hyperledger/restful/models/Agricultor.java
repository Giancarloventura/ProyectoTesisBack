package com.sw.blockchain.hyperledger.restful.models;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="agricultor")
public class Agricultor {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="idAgricultor")
	private Long idAgricultor;
	@Column(name="nombre")
	private String nombre;
	@Column(name="apellidoPaterno")
	private String apellidoPaterno;
	@Column(name="apellidoMaterno")
	private String apellidoMaterno;
	@Column(name="correo")
	private String correo;
	@Column(name="dni")
	private String dni;
	//Foreign key

	@ManyToOne
	@JoinColumn(name="Inspector_idInspector", insertable = false, updatable = false)
	private Inspector inspector;
	
	@OneToMany(mappedBy = "agricultor")
    private List<Parcela> parcelas;
	//@Column(name="Inspector_Administrador_idAdministrador")
	//private Long inspector_administrador_idAdministrador;
	//@Column(name="Inspector_Administrador_Almacenero_idAlmacenero")
	//private Long inspector_administrador_almacenero_idAlmacenero;
}