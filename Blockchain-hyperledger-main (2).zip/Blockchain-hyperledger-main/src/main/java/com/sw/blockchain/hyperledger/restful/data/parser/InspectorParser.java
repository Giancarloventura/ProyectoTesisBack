package com.sw.blockchain.hyperledger.restful.data.parser;

import com.sw.blockchain.hyperledger.restful.data.dto.InspectorDTO;
import com.sw.blockchain.hyperledger.restful.models.Inspector;

public class InspectorParser {
		public static InspectorDTO toDto(Inspector agricultor) {
	        return BaseParser.parse(agricultor,InspectorDTO.class);
	    }
	    public static Inspector fromDto(InspectorDTO agricultorDTO) {
	        return BaseParser.parse(agricultorDTO,Inspector.class);
	    }
}
