package com.sw.blockchain.hyperledger.restful.data.parser;

import com.sw.blockchain.hyperledger.restful.data.dto.RegistroDTO;
import com.sw.blockchain.hyperledger.restful.data.dto.SesionDTO;
import com.sw.blockchain.hyperledger.restful.data.dto.UsuarioDTO;
import com.sw.blockchain.hyperledger.restful.models.Usuario;

public class UsuarioParser {
	public static UsuarioDTO toDto(Usuario usuario) {
        return BaseParser.parse(usuario, UsuarioDTO.class);
    }
	public static Usuario fromDto(RegistroDTO registroDTO) {
	    return BaseParser.parse(registroDTO, Usuario.class);
	}

    public static RegistroDTO fromLogin(SesionDTO sesionDTO) {
        return RegistroDTO.builder()
                .email(sesionDTO.getEmail())
                .password(sesionDTO.getPassword())
                .build();
    }
}
