package com.sw.blockchain.hyperledger.restful.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.SessionFactory;
import org.hibernate.jpa.HibernateEntityManagerFactory;
import org.springframework.context.annotation.Bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@SuppressWarnings("deprecation")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="foto")
public class Foto {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="idFoto")
	private Long idFoto;
	@Lob
	@Column(name="foto")
	private String foto;
	//Foreign Key
	@ManyToOne
	@JoinColumn(name="Parcela_idParcela", insertable = false, updatable = false)
	private Parcela parcela;
	
	//Blob Configuration
	@Bean // Need to expose SessionFactory to be able to work with BLOBs
	public SessionFactory sessionFactory(HibernateEntityManagerFactory hemf) {
	    return hemf.getSessionFactory();
	}
}
