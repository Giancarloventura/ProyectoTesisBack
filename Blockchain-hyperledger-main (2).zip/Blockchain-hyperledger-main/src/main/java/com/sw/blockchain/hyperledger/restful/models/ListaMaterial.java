package com.sw.blockchain.hyperledger.restful.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="listamaterial")
public class ListaMaterial {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="idMaterial")
	private Long idMaterial;
	@Column(name="nombre")
	private String nombre;
	@Column(name="cantidad")
	private Integer cantidad;
	@Column(name="estado")
	private String estado;
	@Column(name="valor")
	private Float valor;
	@Column(name="abonamiento")
	private Integer abonamiento;
	@Column(name="dosis_aplicada")
	private Integer dosisAplicada;
	@Column(name="descripcion")
	private String descripcion;
	//Foreign key
	@ManyToOne
	@JoinColumn(name="Insumos_idInventario", insertable = false, updatable = false)
	private Inventario inventario;
	//@Column(name="InventarioInsumo_Parcela_idParcela")
	//private Long inventarioInsumo_parcela_idParcela;
	//@Column(name="InventarioInsumo_Parcela_Familia_idFamilia")
	//private Long inventarioInsumo_parcela_familia_idFamilia;
}