package com.sw.blockchain.hyperledger.restful.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sw.blockchain.hyperledger.restful.models.Parcela;

public interface IParcelaDao extends JpaRepository<Parcela, Long>{

}
