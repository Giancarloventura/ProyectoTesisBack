package com.sw.blockchain.hyperledger.restful.services.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sw.blockchain.hyperledger.restful.data.dto.AgricultorDTO;
import com.sw.blockchain.hyperledger.restful.data.parser.AgricultorParser;
import com.sw.blockchain.hyperledger.restful.data.repository.IAgricultorDao;
import com.sw.blockchain.hyperledger.restful.models.Agricultor;
import com.sw.blockchain.hyperledger.restful.services.IAgricultorService;

@Service
public class AgricultorService implements IAgricultorService{
	@Autowired 
	private IAgricultorDao agricultoresDao;

	@Override
	public void guardar(AgricultorDTO entity) {
		this.agricultoresDao.save(AgricultorParser.fromDto(entity));
	}

	@Override
	public List<AgricultorDTO> obtenerLista() {
		
		List<Agricultor> agricultores = new ArrayList<>();
		agricultores.addAll(this.agricultoresDao
				.findAll());
		return agricultores.stream().map(AgricultorParser::toDto).collect(Collectors.toList());
	}

	@Override
	public void eliminar(Long id) {
		this.agricultoresDao.deleteById(id);
	}
}
